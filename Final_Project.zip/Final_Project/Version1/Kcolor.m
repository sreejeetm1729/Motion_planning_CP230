%% Team 8
% main code for k-color robot motion planning problem in this version we
% are only considering translating disc robots and k = 1 case.
%% Initializations
clc,clear;
m = 5;                         % # of robots
n = 5;                         % # of nodes in pumped configuration
g = 2;                          % # of pumped graphs
q = 500;
mu = 150;                       % maximum # of single robot configurations
start_lim = [-10 -10];
end_lim = [10 10];
robot_radius = 0.5;
safety_margin = 0.1;
un_Roadmap_Graph = struct('Vertices',[],'Edges',[]); % unconnected roadmap
Start = [unifrnd(start_lim(1),end_lim(1),m,1) unifrnd(start_lim(2),end_lim(2),m,1)];
Terminal = [unifrnd(start_lim(1),end_lim(1),m,1) unifrnd(start_lim(2),end_lim(2),m,1)];
%% Generating Pumped Configuration Graphs
[Roadmap_Graph, Pebble_Graph] = Pre_Process(un_Roadmap_Graph,g,q,n,mu,m,start_lim,end_lim,robot_radius,safety_margin);
Path = Query(Start,Terminal,Pebble_Graph,Roadmap_Graph,q,mu,m,robot_radius,safety_margin);
%% Trajectory Generation
if(~isempty(Path))
    disc_steps = 100;
    intervals = size(Path,3)-1;
    Traj = [];
    for i = 1:intervals
        step_array = (Path(:,:,i+1)-Path(:,:,i))/(disc_steps-1);
        j = (i-1)*disc_steps + 1;
        for k = j:j+disc_steps-1
            Traj(:,:,k) = Path(:,:,i) + (k-j)*step_array;
        end
    end
end
%% Visualization
if(~isempty(Path))
    animate(Path,Traj,start_lim,end_lim,robot_radius,m);
end