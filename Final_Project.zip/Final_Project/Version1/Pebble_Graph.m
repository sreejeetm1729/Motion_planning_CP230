function G = Pebble_Graph(n,sl,el,r,sm)
    V = Pumped_Configuration(n,sl,el,r,sm);
    E =[];
    edge_row = 1;
    for i = 1:n-1
        for j = i+1:n
            path_check = Edge_Planner(V(i,:),V(j,:),V,r,sm);
            if path_check == 0
                E(edge_row,:,1) = V(i,:);
                E(edge_row,:,2) = V(j,:);
                edge_row = edge_row + 1;
            end
        end
    end
    G = struct('Vertices',V,'Edges',E);
end