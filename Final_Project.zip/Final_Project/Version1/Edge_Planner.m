function path_check = Edge_Planner(v1,v2,V,r,sm)

    path_len = dist(v1,v2');
    ver_vec = V - v1;
    cr_pd = ver_vec*(flip(v1-v2).*[-1 1])';
    cr_pd(cr_pd == 0) = [];
    nor_vec_len = abs(cr_pd)/path_len;
    path_check = sum(nor_vec_len<(2*r+sm));

end
