function P = Retrieve_Path(G,H,S,T)
    con_mat = zeros(size(G,2)+2);
    Is = find(ismember(H.Edges(:,:,1),S,'rows'));
    It = find(ismember(H.Edges(:,:,2),T,'rows'));
    g = size(G,2);
    for i = 1:g
        [~,Ia,~] = intersect(H.Edges(Is,:,2),G(i).PG.Vertices,'rows');
        if ~isempty(Ia)
            con_mat(1,i+1) = 1;
        end
        [~,Ib,~] = intersect(H.Edges(It,:,1),G(i).PG.Vertices,'rows');
        if ~isempty(Ib)
            con_mat(i+1,end) = 1;
        end
    end
    for j = 1:g
        for k = 1:g
            if(k~=j)
                Ig = find(ismember(H.Edges(:,:,1),G(j).PG.Vertices,'rows'));
                [~,Ic,~] = intersect(H.Edges(Ig,:,2),G(k).PG.Vertices,'rows');
                if ~isempty(Ic)
                    con_mat(j+1,k+1) = 1;
                end
            end
        end
    end

    [rows,cols] = find(con_mat==1);
    way = [4];
    while(isempty(find(way == 1, 1)))
        t_way = [];
        for i = 1:size(way,1)
            par = rows(cols == way(i,1));
            t_way = [t_way ;[par repelem(way(i,:),size(par,1),1)]];
            if(~isempty(find(par == 1, 1)))
                break;
            end
        end
        way = t_way;
    end
    [~,way_ind] = min(way(:,1));
    act_way = way(way_ind,2:size(way,2)-1)-1;
    P(:,:,1) = S;
    for i = 1:size(act_way,2)
        [~,I1,~] = intersect(H.Edges(Is,:,2),G(act_way(i)).PG.Vertices,'rows','stable');
        I1 = Is(I1);
        [~,~,I2] = intersect(P(:,:,i),H.Edges(I1,:,1),'rows','stable');
        ch = H.Edges(I1,:,2);
        P(:,:,i+1) = ch(I2,:);
        Is = find(ismember(H.Edges(:,:,1),P(:,:,i+1),'rows'));
    end
    [~,I1,~] = intersect(H.Edges(Is,:,2),T,'rows','stable');
    I1 = Is(I1);
    [~,~,I2] = intersect(P(:,:,i+1),H.Edges(I1,:,1),'rows','stable');
    ch = H.Edges(I1,:,2);
    P(:,:,i+2) = ch(I2,:);
end